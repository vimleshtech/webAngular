import { Component, OnInit  } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
  title = 'demo';
  data 
  constructor()
  {
    this.data = []
  }

  ngOnInit()
  {
    fetch("https://jsonplaceholder.typicode.com/todos")
    .then(res=> res.json())
    .then(out => this.data= out)

  }



}

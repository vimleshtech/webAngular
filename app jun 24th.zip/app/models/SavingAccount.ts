import { BankAccount } from "./BankAccount";

export class SavingAccount extends BankAccount{

    gender
    adharno
    
    newAccount(cname)
    {
        this.acname =cname
        this.acno=0
        this.address=''
        this.gender=''
        this.panno=''
        this.adharno=''
        

    }

    showDetails()
    {
        console.log("saving account :"+this.acname)
    }

}
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SalesOrderComponent } from './sales-order/sales-order.component';
import { EmpComponent } from './emp/emp.component';

import  {HttpClientModule} from '@angular/common/http'


@NgModule({
  declarations: [
    AppComponent,
    SalesOrderComponent,
    EmpComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

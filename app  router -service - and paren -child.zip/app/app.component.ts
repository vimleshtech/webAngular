import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  title = 'app'
  name ='Raman Sinha';
  email

  emps
  constructor()
  {
    this.emps = []
  }
  readName(event)
  {
    this.name = event.target.value

  }

  readEmail(event)
  {
    this.email = event.target.value
    
  }
  add()
  {
    this.emps.push({name:this.name,email:this.email})
  }
}

import { Component, OnInit } from '@angular/core';

import {Product} from '../Models/Products'
// .. : one directory/folder up 

@Component({
  selector: 'app-sales-order',
  templateUrl: './sales-order.component.html',
  styleUrls: ['./sales-order.component.css']
})
export class SalesOrderComponent implements OnInit {


  proList:Product[]=[{pid:1,pname:'dove',price:100},{pid:1,pname:'dove',price:100}]

  constructor() { 

    
  }

  ngOnInit() {
  }

}

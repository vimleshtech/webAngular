import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-local-example',
  templateUrl: './local-example.component.html',
  styleUrls: ['./local-example.component.css']
})
export class LocalExampleComponent implements OnInit {

  name  :string
  constructor() {

    this.name =''
   }

  ngOnInit() {
  }

  takeName(event){

    this.name = event.target.value 
    localStorage.setItem('data',this.name)
    
    console.log(this.name)

  }

  add()
  {
      console.log(localStorage.getItem('data'))
  }
}

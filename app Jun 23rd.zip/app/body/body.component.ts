import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

  emailid
  name
  mobileno

  constructor() { 

      this.name="Nitin"
      this.emailid="nitin@gmail.com"
      this.mobileno=''

  }

  takeInput(event)
  {
      this.mobileno = event.target.value;
      
  }
  ngOnInit() {
  }

}

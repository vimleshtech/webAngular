import { UselessPipePipe } from './useless-pipe.pipe';

describe('UselessPipePipe', () => {
  it('create an instance', () => {
    const pipe = new UselessPipePipe();
    expect(pipe).toBeTruthy();
  });
});

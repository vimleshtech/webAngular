export class BankAccount{


            acno
			acname
			address
            panno
            
}
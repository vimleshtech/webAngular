import { MyhelpDirective } from './myhelp.directive';

describe('MyhelpDirective', () => {
  it('should create an instance', () => {
    const directive = new MyhelpDirective();
    expect(directive).toBeTruthy();
  });
});

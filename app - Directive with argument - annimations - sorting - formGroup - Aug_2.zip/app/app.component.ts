import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  testdata ='hi and hellow'
    name
    n
    cl
    c
    dob
    d
    stream
    s
    hobbies
    h
   
    pname
    pid
    prices
    pn
    pi
    pp
    pdata
    pmid

    data
    upd
    hid 
    mdata 
    search
    constructor()
  {
    this.data =[]
    this.mdata = []
    this.pdata=[]
  }
  searchfilterbyname(event)
  {
    this.search= event.target.value
  }
  takename(event)
  {
    this.name = event.target.value
  }
  takeclas(event)
  {
    this.cl = event.target.value
  }
  takedob(event)
  {
    this.dob = event.target.value
  }
  takestream(event)
  {
    this.stream = event.target.value
  }
  takehobbies(event)
  {
    this.hobbies = event.target.value
  }
  takepname(event)
  {
    this.pname=event.target.value
  }
  takepid(event)
  {
    this.pid=event.target.value
  }
  takeprice(event)
  {
    this.prices=event.target.value
  }
  deleteRow(ind){
    this.data.splice(ind,1)
  }
  updateRow(ind){
    this.hid = ind 
    this.name = this.data[ind].name
    this.cl= this.data[ind].cl
    this.dob = this.data[ind].dob
    this.stream = this.data[ind].stream
    this.hobbies = this.data[ind].hobbies
  }
  updateinput(){
    this.data[this.hid].name=this.name
    this.data[this.hid].cl=this.cl
    this.data[this.hid].dob=this.dob
    this.data[this.hid].stream=this.stream
    this.data[this.hid].hobbies=this.hobbies
  }
  finalres() 
  {
    this.n =this.name
    this.c =this.cl
    this.d=this.dob
    this.s=this.stream
    this.h=this.hobbies

    this.data.push({name:this.n,class:this.cl,dob:this.d,stream:this.s,hobbies:this.h})
    this.mdata = this.data
  }
  sortingbyname()
  {
    this.data.sort((x,y)=>x.name.localeCompare(y.name))  
  }
  filterbyname()
  {
   this.data = this.mdata.filter(data=>data.name ==this.search)
  }
  viewall()//not working
  {
    this.data=this.mdata
  }
  addrow()
  {
    this.pn=this.pname
    this.pi=this.pid
    this.pp=this.prices
    this.pdata.push({pname:this.pn,pid:this.pi,prices:this.pp})
  }
  deleterow2(index)
  {
    this.pdata.splice(index,1)
  }
  editrow(index)
  {

      this.pmid = index 
      this.pname = this.pdata[index].pname
      this.pid = this.pdata[index].pid
      this.prices = this.pdata[index].prices
  /*
    this.pmid=index
    this.pname=this.pdata[index].pname
    console.log(this.pname)
    this.pid=this.pdata[index].pid
    this.prices=this.pdata[index].prices
  */}
/*  updaterow(index)
  {
    this.pdata[this.pmid].pname=this.pname
    this.pdata[this.pmid].pid=this.pid
    this.pdata[this.pmid].prices=this.prices
  }*/
}
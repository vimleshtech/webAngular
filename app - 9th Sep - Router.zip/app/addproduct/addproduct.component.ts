import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  name ="test name"
  constructor() { }

  takeName(event)
  {
      this.name = event.target.value 
      
  }
  ngOnInit() {
  }

}

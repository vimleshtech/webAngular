import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalExampleComponent } from './local-example.component';

describe('LocalExampleComponent', () => {
  let component: LocalExampleComponent;
  let fixture: ComponentFixture<LocalExampleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocalExampleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocalExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import {Customer} from '../models/customer'
import { TestserviceService } from '../testservice.service';
import { SavingAccount } from '../models/SavingAccount';
import { CurrentAccount } from '../models/CurrentAccount';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  Mname
  Memail
  Mpass
  Mdata = []
  constructor(private o: TestserviceService, private sa:SavingAccount, private ca:CurrentAccount) { }

  ngOnInit() {

    console.log(this.o.add(11,22))
    this.sa.newAccount("Nitin Sinha");
    this.ca.newAccount("Tech Vision Information Services");
    
    this.ca.showDetails()
    this.sa.showDetails()


  }


    GetData(){
        
        this.Mdata.push(new Customer( this.Mname,this.Memail,this.Mpass))
        console.log(this.Mdata)

      
      
    }
}

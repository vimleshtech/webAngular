import { Directive,ElementRef, Input,HostListener,OnInit } from '@angular/core';

@Directive({
  selector: '[appDirArgu]'
})
export class DirArguDirective implements OnInit {

  @Input() mydata:string

  constructor(obj : ElementRef) {

    obj.nativeElement.innerHTML ="hi";

   }

   ngOnInit()
   {

    alert(this.mydata)

   }

   @HostListener('mouseenter') onMouseEnter() 
  { 
  
      alert(this.mydata); 

  }


}

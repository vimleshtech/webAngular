import { Component, OnInit } from '@angular/core';
//orderby ----sort
//search---filter
//splice--
//data type--- number, string, boolean, object,function
@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
 
  tcount=0
  markcount=0
  unmarkcount=0

  inputval;
 price;
 quantity;
 birthday="12/1/1988";
 total;
 items=[];
 editprice;
 editquantity;
 isOn=false;rowcreate=[]
 itmid="";
 itmprc="";
 itmqty="";
 updatedindx;
 mgs="hiii this is mesage for pipe";
 pipearray;
   btnclk(){alert(this.inputval)}
  
  textchng(event){this.inputval=event.target.value}
  
  calculate(p,q){this.total=p*q}
  edit(id,ind){
    this.updatedindx=ind;
    this.itmid=this.items[ind].id;
    this.itmprc=this.items[ind].price
    this.itmqty=this.items[ind].quantity;
    //this.rowcreate[id]=true
  
  }
  updateprice(p,indx){
    console.log(p);
    this.items[indx].price=p;
    console.log(this.items);
   // var a = [1, 2, 3, 4, 5 ,6],
//  this.items.forEach(function(key,value){
//    if(this.items[key].id==id){
//      this.items[key].price=p;
//    }
// });
    // Object.entries(this.items).forEach(([key, value]) => {
    //   console.log(JSON.parse(value));
    //   if(key=="id"){
        
    //   }
    // })
   // var itm=this.items.filter(itm=>(itm.id==id))
  //console.log(itm);
  }
  chngid(val){
    this.itmid=val;
  }
  chngprice(val){
    this.itmprc=val;
  }
  chngqnty(val){
    this.itmqty=val;
  }

 
  update(id,prc,qty){
    this.items[this.updatedindx].id=this.itmid;
    this.items[this.updatedindx].price=this.itmprc;
    this.items[this.updatedindx].quantity=this.itmqty;
//var valu= "editprice"+id
   alert(this.editprice+this.editquantity);
   // this.items.slice({"id":id,"price":p,"quantity":q})
  // this.storedata= this.items;
  }
  sortItem(sortval){
    this.items.sort((a, b) => (-parseInt(a[sortval])+parseInt(b[sortval])))
  // this.items.sort((x,y)=>x[sortval])
  }
  addItem(id,p,q){
    this.items.push({"id":id,"price":p,"quantity":q,"isMark":false});
   // this.storedata= this.items;
   this.markCount()
  }
  constructor() {
    this.items=[];
    this.editprice=[];
    this.pipearray=["aaa","cccc","fff","bbn","ddd"];
   }
   deletefun(id){
     var temp=this.items;
    this.items.some(function(item, index) {
      if(temp[index].id === id){
        // found it!
        temp.splice(index, 1);
        this.items=temp;
        return true; // stops the loop
      }
      return false;
    });
    console.log(this.items);
  //  alert( this.items.filter(x => x.id != id));
  }
  storedata;
  search(event){
    this.items=this.storedata;   
      var a= this.items.filter(x => x.id == event.target.value);// || x.price == event.target.value || x.quantity == event.target.value
      this.items=a;
  
  return this.items;
  }
  delMarkRow()
  {

    this.items = this.items.filter(a=> a.isMark==false);
    this.markCount();
    
  }
  markfun(i)
  {
      this.items[i].isMark =!this.items[i].isMark;
      this.markCount();     
  }
  markCount()
  {
    this.tcount =0;
    this.unmarkcount = 0;
    this.markcount  = 0;

    for(let i=0;i<this.items.length;i++ )
    {
        if(this.items[i].isMark == true)
          {
            this.markcount = this.markcount+1
          }
    }
    this.tcount = this.items.length
    this.unmarkcount = this.tcount - this.markcount

  }
  ngOnInit() {
  }

}

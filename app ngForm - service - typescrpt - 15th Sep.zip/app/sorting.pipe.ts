import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sorting'
})
export class SortingPipe implements PipeTransform {

  /*
  varname:datatype 
         :number
         :string
         :any / all types
  varname?    : optioanl (may or may not)      
  */
  
  transform(value, args?: any): any {
  
      var d = value.length

      return d;
  }

}

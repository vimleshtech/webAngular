import { TextarrangePipe } from './textarrange.pipe';

describe('TextarrangePipe', () => {
  it('create an instance', () => {
    const pipe = new TextarrangePipe();
    expect(pipe).toBeTruthy();
  });
});

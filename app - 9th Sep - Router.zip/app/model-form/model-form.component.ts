import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormControl } from '@angular/forms';


@Component({
  selector: 'app-model-form',
  templateUrl: './model-form.component.html',
  styleUrls: ['./model-form.component.css']
})
export class ModelFormComponent   implements OnInit {

  strmsg=''
  langs: string[] = [
    'English',
    'French',
    'German',
  ]
  lan  
  myform: FormGroup;


  constructor() {  

    this.strmsg='required field';
    this.lan  =[]

    
  }

  readL(event)
  {
    console.log(event.target.value) 
  }
  ngOnInit() {
    
    var name;
    name ='11' //local 

    

    this.myform = new FormGroup({
        name: new FormGroup({ 
            firstName: new FormControl(), 
            lastName: new FormControl(),
        }),
        email: new FormControl(),
        password: new FormControl(),
        language: new FormControl()
    });
  }

  
  savedata()
  {
    var dd =  this.myform.value
    console.log(dd)


  }

}

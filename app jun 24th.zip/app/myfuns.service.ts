import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyfunsService {

  constructor() { }

  add(a,b):any{

    var c =a+b
    return c

  
  
  }

  sub(a,b):any{

    var c =a-b
    return c

  
  
  }

  

}

import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appDirex]'
})
export class DirexDirective {

  constructor(Element: ElementRef) {
    console.log(Element);
    Element.nativeElement.innerText="Text Changed ";
 }


}

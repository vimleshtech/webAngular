const mysql = require('mysql')

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "testdb"
  });


class user{

    saveData(obj)
    {

        
        con.connect(function(err) {


            if (err) throw err;
            
            var sql = "insert into product(pid,pname,price) values(11,'sony phone',33000)";                        
            
            con.query(sql, function (err, result) {
                if (err) throw err;
                console.log("Number of records inserted: " + result.affectedRows);
              });
     
              
         });        
          
         

        
    }

}

module.exports = user;

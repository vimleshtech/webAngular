import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyutilsService {

  constructor() { }

  add(a:number,b:number):number
  {
      var c =a+b;
      return c;
  }

  incomeTax(sal:number){

    var tax;

    if(sal<=300000)
    {
        tax =0;
    }
    else if (sal<=500000)
    {
        tax = (sal-300000)*.05;
    }
    else if (sal<=1000000)
    {
      tax = 10000+(sal-500000)*.20;
    }
    else 
    {
      tax = 110000+(sal-1000000)*.30;
    }

    return tax;
  }
}

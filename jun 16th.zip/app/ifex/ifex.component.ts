import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ifex',
  templateUrl: './ifex.component.html',
  styleUrls: ['./ifex.component.css']
})
export class IfexComponent implements OnInit {
  isValid: boolean = true;
  age:number = 12;
  showStyle: false;
  country:'UK'
  
  constructor() { }

  ngOnInit() {
  }
  changeValue(valid: boolean) {
    
    this.isValid = valid;

  }

  getStyle() {

    if(this.showStyle) {
    
      return "yellow";
    } else {
    
      return "red";
    }
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//to add /use ngModel we need to import FormsModule
import {FormsModule}        from '@angular/forms';



import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BodyComponent } from './body/body.component';

import { ProductsComponent } from './products/products.component';
import { SortingpipePipe } from './sortingpipe.pipe';
import { TextarrangePipe } from './textarrange.pipe';
import { MydiccustomDirective } from './mydiccustom.directive';
import { MyhelpDirective } from './myhelp.directive';
import { CustomerComponent } from './customer/customer.component';
import { SavingAccount } from './models/SavingAccount';
import { CurrentAccount } from './models/CurrentAccount';




@NgModule({
  //compoentn 
  declarations: [
    SortingpipePipe,
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BodyComponent,
    ProductsComponent,
    TextarrangePipe,
    MydiccustomDirective,
    MyhelpDirective,
    CustomerComponent
    
  ],//modules 
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [CurrentAccount,SavingAccount],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { MydesignDirective } from './mydesign.directive';

describe('MydesignDirective', () => {
  it('should create an instance', () => {
    const directive = new MydesignDirective();
    expect(directive).toBeTruthy();
  });
});

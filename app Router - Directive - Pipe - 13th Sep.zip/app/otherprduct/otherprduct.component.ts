import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otherprduct',
  templateUrl: './otherprduct.component.html',
  styleUrls: ['./otherprduct.component.css']
})
export class OtherprductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

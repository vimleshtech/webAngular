import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  name 
  data 
  constructor() { 

    this.name =''
    this.data = []

  }

  ngOnInit() {
  }
  takeName(event)
  {
    this.name = event.target.value 

  }
  add()
  {
    this.data.push({name:this.name})
  }
}

import { MydiccustomDirective } from './mydiccustom.directive';

describe('MydiccustomDirective', () => {
  it('should create an instance', () => {
    const directive = new MydiccustomDirective();
    expect(directive).toBeTruthy();
  });
});

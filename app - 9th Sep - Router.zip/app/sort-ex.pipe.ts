import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortEx'
})
export class SortExPipe implements PipeTransform {

  transform(value: any, args?: any): any {

    if(args=='asc')
    {
      return value.sort();

    }
    else
    {
      return value.sort().reverse();

    }
    
  }

}

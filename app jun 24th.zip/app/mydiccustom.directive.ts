import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appMydiccustom]'
})
export class MydiccustomDirective {

  constructor(el:ElementRef) {


    el.nativeElement.innerHTML ="data is coming from directive";
    el.nativeElement.style.color="red"
    el.nativeElement.innerHTML="User :<input type='text' /> Password <input type='password' />"


   }

}

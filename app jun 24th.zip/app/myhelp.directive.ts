import { Directive } from '@angular/core';

@Directive({
  selector: '[appMyhelp]'
})
export class MyhelpDirective {

  constructor() { }

}

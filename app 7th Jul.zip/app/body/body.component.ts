import { Component, OnInit } from '@angular/core';
import {WebapiService} from '../webapi.service';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
 data:any;
 blogs :any;
  constructor(private WebapiService:WebapiService) { }

  ngOnInit() {
    this.WebapiService.gettypes()
    .subscribe((data) => {
    console.log(data)
    this.data = data;
    });

    this.WebapiService.getblogs()
    .subscribe((blogs) => {
    console.log(blogs)
    this.blogs = blogs;
    });
  }

  postnow(deviceValue) {
    console.log(deviceValue); 
  alert(deviceValue)

  }
  

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() {
    this.body1="";
    this.body2="";
   }
 body1;
 body2;
 loadbody(bdy){
   if(bdy=="body1"){
    this.body1=true;
   }
   if(bdy=="body2"){
    this.body2=true;
   }
   
 }
 
  ngOnInit() {
  }

}

import { TestBed, inject } from '@angular/core/testing';

import { MyutilsService } from './myutils.service';

describe('MyutilsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyutilsService]
    });
  });

  it('should be created', inject([MyutilsService], (service: MyutilsService) => {
    expect(service).toBeTruthy();
  }));
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormDriComponent } from './form-dri.component';

describe('FormDriComponent', () => {
  let component: FormDriComponent;
  let fixture: ComponentFixture<FormDriComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormDriComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormDriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

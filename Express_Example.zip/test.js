const express = require('express')
const app = express()

const user = require('./controller/userController.js')
let u =new user()
const product = require('./controller/productController.js')
let p =new product()


app.get('/',(req,res)=>res.send("test"))

app.get('/save',function(req,res){




    u.saveData(v);

    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    
    res.send("data saved");


})
app.get('/about',(req,res) => res.send("about"))
app.get('/test',(req,res) => res.send("test"))
app.listen(3005,() =>console.log('listing on port 3005!'))





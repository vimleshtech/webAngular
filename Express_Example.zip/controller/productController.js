class product{

    

}
module.exports = product;
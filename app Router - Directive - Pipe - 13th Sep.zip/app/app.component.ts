import { Component,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit  {
  
  title = 'app'
  name ='Raman Sinha';
  email
  lists
  data_1 = ["raman","jatin","aman"]
  
  emps
  constructor(private http:HttpClient)
  {
    this.lists=[]
    this.emps = []
  }
  ngOnInit()
  {
    //read 
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(res => res.json())
    .then(out => this.lists= out)


    // this.http.get("https://jsonplaceholder.typicode.com/posts/2")
    // .subscribe((data) =>  {
    //   this.lists.push(data);
    //   console.log(data);
    //   });

    
    //post 
    var a,b;
    a =333;
    b =44;
    //https://mail.google.com/mail/?tab=wm
    // //pass data via query sting 
    // fetch('https://jsonplaceholder.typicode.com/posts?k1='+a+'&k2='+b)
    // .then(res => res.json())
    // .then(out => this.lists= out)

    //or 

    // fetch('https://jsonplaceholder.typicode.com/posts',
    //   {
    //       method:'post',
    //       body:a,

    //   }
    // )
    // .then(res => res.json())
    // .then(out => this.lists= out)
    
    
  }

  readName(event)
  {
    this.name = event.target.value

  }

  readEmail(event)
  {
    this.email = event.target.value
    
  }
  add()
  {
    this.emps.push({name:this.name,email:this.email})
  }
}

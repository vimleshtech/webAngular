import { DirArguDirective } from './dir-argu.directive';

describe('DirArguDirective', () => {
  it('should create an instance', () => {
    const directive = new DirArguDirective();
    expect(directive).toBeTruthy();
  });
});

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ModelFormComponent } from './model-form/model-form.component';

import { ReactiveFormsModule} from '@angular/forms';
import { ModelValidateComponent } from './model-validate/model-validate.component';

import { HttpClientModule } from '@angular/common/http';
import { WebApiComponent } from './web-api/web-api.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EmpDetailComponent } from './emp-detail/emp-detail.component';
import { EmpsComponent } from './emps/emps.component';

import {SalaryCal} from './oops/salarycalc';
import { SortingPipe } from './sorting.pipe';
import { SortExPipe } from './sort-ex.pipe';
import { CrudComponent } from './crud/crud.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component'

import { RouterModule } from '@angular/router';
import { Router } from '@angular/router/src/router';
import { moduleProvideDef } from '@angular/core/src/view/ng_module';
import { MydesignDirective } from './mydesign.directive';

@NgModule({
  declarations: [
    AppComponent,
    ModelFormComponent,
    ModelValidateComponent,
    WebApiComponent,
    EmpDetailComponent,
    EmpsComponent,
    SortingPipe,
    SortExPipe,
    CrudComponent,
    ParentComponent,
    ChildComponent,
    MydesignDirective,
  ],
  imports: [
    ReactiveFormsModule,
    BrowserModule,   
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    RouterModule.forRoot([
            {path: '',component:ModelFormComponent},
            {path: 'parent',component:ParentComponent}
   ])

    
  ],
  providers: [SalaryCal],
  bootstrap: [AppComponent]
})
export class AppModule { }

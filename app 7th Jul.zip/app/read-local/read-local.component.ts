import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http'; 


@Component({
  selector: 'app-read-local',
  templateUrl: './read-local.component.html',
  styleUrls: ['./read-local.component.css']
})
export class ReadLocalComponent implements OnInit {

  constructor(private http:HttpClient) { }

  ngOnInit() {

    this.http.get("http://jsonplaceholder.typicode.com/users")
    .subscribe((data) => console.log(data))

    }

  readData()
  {
      console.log(localStorage.getItem('data'))
   


    
    var data={'id':'111','name':'shsgs'}

      //call to web api 
      let fetchData = { 
        method: 'POST', 
        body: data,
        headers: new Headers()
    }
    //data
    fetch("http://localhost/test/user.php" )
    .then((resp) => resp.json()) // Transform the data into json
    .then(function(data) {
      console.log(data)
                //2nd api 
                console.log("new api");

                fetch("http://jsonplaceholder.typicode.com/users")
                .then((out) => out.json())
                .then(function(o){

                    console.log(o);
                })
    })
  



  }

}

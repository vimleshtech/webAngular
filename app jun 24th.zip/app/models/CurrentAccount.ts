import { BankAccount } from "./BankAccount";

export class CurrentAccount extends BankAccount{
    gstno
    regtno
   
    newAccount(cname)
    {
        this.acname =cname
        this.acno=0
        this.address=''
        this.gstno=''
        this.panno=''
        this.regtno=''
        

    }

    showDetails()
    {
        console.log("current account :"+this.acname)
    }
   
}
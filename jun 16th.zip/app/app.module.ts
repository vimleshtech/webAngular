import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import  {HttpClientModule} from '@angular/common/http';
import { IfexComponent } from './ifex/ifex.component';
import { SortingPipe } from './sorting.pipe';
import { DateexPipe } from './dateex.pipe';
import { DirexDirective } from './direx.directive';
import { UselessPipePipe } from './useless-pipe.pipe';
import { MycustompipePipe } from './mycustompipe.pipe';
import { CustomstyleDirective } from './customstyle.directive'

@NgModule({
  declarations: [
    AppComponent,
    IfexComponent,
    SortingPipe,
    DateexPipe,
    DirexDirective,
    UselessPipePipe,
    MycustompipePipe,
    CustomstyleDirective
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Injectable } from '@angular/core';

//@ annotation : inbuilt propeties 

@Injectable({
  providedIn: 'root'
})
export class TestserviceService {

  constructor() { }


  add(a,b):number{

    var c =a+b;
    return c;

  }
}

import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustdir]'
})
export class CustdirDirective {

  constructor(ele:ElementRef) {

    ele.nativeElement.style.color="red";
    

   }

}

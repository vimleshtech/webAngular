import { SortExPipe } from './sort-ex.pipe';

describe('SortExPipe', () => {
  it('create an instance', () => {
    const pipe = new SortExPipe();
    expect(pipe).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MethodsService {

  constructor() { }

  add(a,b){
    return a+b
  }

  sub(a,b){

    return a-b
  }

  getdateTime(){

    var d = new Date();
    return d
  }
}

import { Component, OnInit } from '@angular/core';
import { element } from 'protractor';
import {MyfunsService} from '../myfuns.service'
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {


  pagetitle="My Piple Example"
  testdata=['b','a','c']
  newname ="Nitin"

  pid:number
  pname:string
  pprice:number
  products
  productscp
  sortByPrice
  mark
  markIndex
  tmpStore = []
  SortType
  SortPriceTpe 
  FilterText
  FilterResult
  constructor(private o : MyfunsService) {

    this.pid =1
    this.pname='Test'
    this.pprice=45
    this.products=[{pid:4,pname:'dove',pprice:56,flag:false,markColor:''},{pid:3,pname:'lux',pprice:23,flag:false,markColor:''},{pid:7,pname:'nirma',pprice:12,flag:false,markColor:''},{pid:1,pname:'dettol',pprice:22,flag:false,markColor:''}]
    this.productscp=this.products
    this.sortByPrice = []
    this.mark = []
    this.SortType = ''
    this.SortPriceTpe = ''
    this.FilterText = ''
    this.FilterResult = []
   }

  ngOnInit() {

    this.products = this.products.sort((a,b)=>a.pname.localeCompare(b.pname) )
   
    console.log( this.o.add(11,20))



  }

  takePId(event)
  {
    this.pid = event.target.value 

  }
  takePName(event)
  {
    this.pname = event.target.value 
    
  }
  takePPrice(event)
  {
    this.pprice = event.target.value 
    
  }
  
  productAdd(){
    this.products.push({pid:this.pid,pname:this.pname,pprice:this.pprice,flag:false,markColor:''})
    console.log(  this.products )
    this.productscp = this.products
  }
  markProd(index){

    this.products[index].flag = !this.products[index].flag
    if(this.products[index].flag == true){
      this.products[index].markColor = 'red'
    }else{
      this.products[index].markColor = ''

    }
    console.log(this.products[index].flag);
    this.productscp = this.products
  }
  delButton(){

    for(let i = this.products.length - 1; i >= 0; i--) {
      if(this.products[i].markColor == 'red') {
        this.products.splice(i, 1);
      }
    }
    this.productscp = this.products
  }
  
  editProd(index)
  {
  this.pid =   this.products[index].pid
  this.pname=  this.products[index].pname
  this.pprice = this.products[index].pprice
  console.log("edit ")
  this.productscp = this.products
  }
  /* SortPrice(){
        
    if(this.SortType == '' || this.SortType == 'D'){
      this.products = this.products.sort(function(a,b) {
        return a['pprice']-b['pprice']
      });
      this.SortType = 'A'
    }else{
    
      this.products = this.products.sort(function(a,b) {
        return b['pprice']-a['pprice']
      }); 
      this.SortType = 'D'
    }
    this.productscp = this.products 
  } */
  /* SortName(){
    if(this.SortPriceTpe == '' || this.SortPriceTpe == false){
    this.products.sort((a, b) => a.pname.localeCompare(b.pname))
    this.SortPriceTpe = true
    }else{
      this.products.sort((a, b) => b.pname.localeCompare(a.pname))
    this.SortPriceTpe = false

    }
  } */

  AutoSearch(event){
    this.FilterText = event.target.value
    this.products =  this.productscp.filter(prod=> prod.pname == this.FilterText)
    console.log(this.productscp)
  }


  updateProd(){
  
    console.log(this.products.length);

    for(var i=0; i < this.products.length; i++ )
    {
      var v1 = this.products[i].pid;
      var v2= this.pid;
      
      if(v1 ==v2)
      { 
        this.products[i].pid = this.pid
        this.products[i].pname = this.pname
        this.products[i].pprice = this.pprice
      }
    }

  }
}

import { DateexPipe } from './dateex.pipe';

describe('DateexPipe', () => {
  it('create an instance', () => {
    const pipe = new DateexPipe();
    expect(pipe).toBeTruthy();
  });
});

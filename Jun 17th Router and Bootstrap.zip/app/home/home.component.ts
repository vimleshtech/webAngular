import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  id: string;
  cid:string
  private sub: any;    

constructor(private router: Router, private route: ActivatedRoute) {
}
  ngOnInit() {
    
        this.sub = this.route.params.subscribe(ss => {

            this.id = ss['id'];
            this.cid = ss['cid'];
    });

    console.log(this.id);
    console.log(this.cid);
}

onClic()
{
  this.router.navigateByUrl('/user');
}
}

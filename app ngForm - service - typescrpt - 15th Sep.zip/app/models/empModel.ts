
export  class EmployeeModel{

    eid:number
    fname:string
    lname:string
    sal:number
    markdelete:boolean

    addEmployee(eid,fname,lname,sal)
    {
        this.eid = eid;
        this.fname= fname;
        this.lname= lname;
        this.sal= sal;
        this.markdelete = false;

    }
    markDeleteUndelete()
    {
        this.markdelete = !this.markdelete;

    }
    updateEmployee(eid,fname,lname,sal)
    {
        this.eid = eid;
        this.fname= fname;
        this.lname= lname;
        this.sal= sal;
        this.markdelete = false;

    }


}


import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'textarrange'
})
export class TextarrangePipe implements PipeTransform {

  transform(value: any, arg1: any,arg2:any): any {
    
    return arg1+' '+value+' '+arg2


  }

}

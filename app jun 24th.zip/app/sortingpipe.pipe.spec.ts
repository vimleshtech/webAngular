import { SortingpipePipe } from './sortingpipe.pipe';

describe('SortingpipePipe', () => {
  it('create an instance', () => {
    const pipe = new SortingpipePipe();
    expect(pipe).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-model-validate',
  templateUrl: './model-validate.component.html',
  styleUrls: ['./model-validate.component.css']
})
export class ModelValidateComponent implements OnInit {
  
    registerForm: FormGroup;
    submitted = false;

  constructor(private formBuilder: FormBuilder) { }

  testFun(event)
  {
    var dd =event.target.value;
    if(dd=="abcd@gmail.com")
    {
      console.log('matched ')

    }
    else{
      console.log('not matched ')
    }
  }
  
  ngOnInit() {

      this.registerForm = this.formBuilder.group({   

          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          salary:['',[Validators.required,Validators. required]],
          email: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required, Validators.minLength(6)]]

      });
  }

  // convenience getter for easy access to form fields
  
  get f() { 
  
    return this.registerForm.controls; 
  
  }

  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

      alert('SUCCESS!! :-)'+this.registerForm)
  }
}
import { Component, OnInit } from '@angular/core';

import  {HttpClientModule, HttpClient} from '@angular/common/http'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  mstyle="mystyle";

  testStyle = true;

  title = 'app';
  data

  name

  red='red'
  titleClass = 'red-title';

  mydata=[1111,3222,33344,55]


  customers = [
    {"name" : "Bottom-Dollar Marketse" ,"city" : "Tsawassen"},
    {"name" : "Alfreds Futterkiste", "city" : "Berlin"},
    {"name" : "Bon app", "city" : "Marseille"},
    {"name" : "Cactus Comidas para llevar", "city" : "Buenos Aires"},
    {"name" : "Bolido Comidas preparadas", "city" : "Madrid"},
    {"name" : "Around the Horn", "city" : "London"},
    {"name" : "B's Beverages", "city" : "London"}
    ];
    //sorting 
    //customers.sort((a,b)=>a.name.localeCompare(b.name))
    //customers.sort((a,b)=>b.name.localeCompare(a.name))

    //filter
    //customers.filter(customer => customer.city ==='London');


    fname="Chahat"
    arr=["b","a","c"]


  constructor(private http: HttpClient){
      this.name  =''
      this.data =[]

  }
  ngOnInit():void{

    this.http.get('http://jsonplaceholder.typicode.com/users').subscribe(
      data =>{  this.data = data; //console.log(data);
      }
    );

  }
  takeName(event){
    this.name = event.target.value 
    

  }
}

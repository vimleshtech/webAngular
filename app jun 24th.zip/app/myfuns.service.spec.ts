import { TestBed, inject } from '@angular/core/testing';

import { MyfunsService } from './myfuns.service';

describe('MyfunsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyfunsService]
    });
  });

  it('should be created', inject([MyfunsService], (service: MyfunsService) => {
    expect(service).toBeTruthy();
  }));
});

import { Component } from '@angular/core';
import { MethodsService } from './methods.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  a =1
  b= 2
  c
  constructor(obj:MethodsService){

    this.c = obj.add(this.a,this.b)
  }
}

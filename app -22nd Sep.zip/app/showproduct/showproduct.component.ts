import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showproduct',
  templateUrl: './showproduct.component.html',
  styleUrls: ['./showproduct.component.css']
})
export class ShowproductComponent implements OnInit {

  name 
  constructor() {

    this.name =''
   }

  ngOnInit() {
 
    this.name = localStorage.getItem("empname");


  }

}

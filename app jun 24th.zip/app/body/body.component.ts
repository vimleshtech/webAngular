import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent {

  pagetitle="My Product Application"
  pid
  pname 
  pprice 
  pqty 
  pvalue
  gst
  StoreRecord
  Products
  data=[100,200,300]
  produc = [{id:100,name:'chahat'},{id:333,name:'nitin'},{id:300,name:'raman'}]

  constructor()
  {
    this.pid = 0
    this.pname =''
    this.pprice = 0
    this.pqty = 0
    this.pvalue = 0
    this.gst = 0
    this.Products = []
  }
  calculate(){
    this.pvalue = this.pprice * this.pqty
    this.gst = (this.pvalue * 18) / 100
    this.Products.push({id:this.pid,name:this.pname,price:this.pprice,qty:this.pqty})
  }
  getPID(event)
  {
    this.pid = event.target.value 
  }
  getPNAME(event)
  {
  this.pname = event.target.value 
  }
  getPPRICE(event)
  {
    this.pprice = event.target.value  
  }
  getPQTY(event)
  {
    this.pqty = event.target.value 
  }
}

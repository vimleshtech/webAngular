import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustomstyle]'
})
export class CustomstyleDirective {

  constructor(el:ElementRef) {

    el.nativeElement.style.color="red";
    el.nativeElement.innerHTML = el.nativeElement.innerHTML+"new html";
    



   }

}

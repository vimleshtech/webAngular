import { SortingPipe } from './sorting.pipe';

describe('SortingPipe', () => {
  it('create an instance', () => {
    const pipe = new SortingPipe();
    expect(pipe).toBeTruthy();
  });
});

export class Customer{

    //data members or member variable
	private	cid:number
	private	cname:string
	private	gender:string
	private	phoneno:string
	private	emailid:string
	private	isdelete:boolean=false

	constructor(id,cname,gender,phoneno,emailid)
	{
			this.cid = id;
			this.cname = cname;
			this.gender = gender;
			this.phoneno= phoneno;
			this.emailid = emailid;

	}

		//method or function
		toggle()
		{
			this.isdelete = !this.isdelete
		}
    
        
    

}
 

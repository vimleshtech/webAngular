import { Component } from '@angular/core';

//'@angular/core'; : library / modulee
//Component : is inbuild class


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  //declartion of data memebr or global variable
  id:number
  name:string
  ename:string

  //constructor : is inbuild function which will invoke automatically when component will load or object will create
  //initialization of memory
  constructor(){

    this.id = 100
    this.name ='nitin'
    this.ename =''

  }

  //methods/ event / function 
  takeName(event)
  {
    this.ename = event.target.value 
    console.log(this.ename)
    alert(this.ename);



  }





}

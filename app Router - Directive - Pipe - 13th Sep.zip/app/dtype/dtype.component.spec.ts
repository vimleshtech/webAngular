import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DtypeComponent } from './dtype.component';

describe('DtypeComponent', () => {
  let component: DtypeComponent;
  let fixture: ComponentFixture<DtypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DtypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DtypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import {CommonFunService} from '../common-fun.service'


@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  fn
  ln 
  emps
  constructor(private obj:CommonFunService) {

    this.fn =''
    this.ln =''
    this.emps = []
   }

  ngOnInit() {
  }

  takeFName(event)
  {
    this.fn = event.target.value;
  }
  takeLName(event)
  {
    this.ln = event.target.value;
  }

  Add()
  {
      this.emps.push({fname:this.fn,lname:this.ln});
      console.log( this.obj.tax(1111))
      alert(this.obj.tax(1111))



  }
}

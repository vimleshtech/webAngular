import { DirexDirective } from './direx.directive';

describe('DirexDirective', () => {
  it('should create an instance', () => {
    const directive = new DirexDirective();
    expect(directive).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import {Customer} from '../models/customer'


@Component({
  selector: 'app-modelex',
  templateUrl: './modelex.component.html',
  styleUrls: ['./modelex.component.css']
})
export class ModelexComponent implements OnInit {

  custs=[]

  constructor() { //c is object of class Customer 
    
  

   }
   addCustomer()
   {
    this.custs.push(new Customer(1,"a","b","c","d"))

   // this.custs.push(this.c.addCust(1,"a","b","c","d"))

    console.log(this.custs)

   }

  ngOnInit() {
  }

}

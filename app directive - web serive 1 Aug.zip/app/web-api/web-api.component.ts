import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

enum Direction {
  Up,
  Down,
  Left,
  Right,
}
enum Response {
  No = 0,
  Yes = 1,
}


@Component({
  selector: 'app-web-api',
  templateUrl: './web-api.component.html',
  styleUrls: ['./web-api.component.css']
})
export class WebApiComponent implements OnInit {

  
  lists=[]

  constructor(private http: HttpClient) { 

    this.lists=[]
  }

  ngOnInit() {
   


  // fetch('https://jsonplaceholder.typicode.com/posts/1')
  // .then(response => response.json())
  // .then(json => console.log(json))

  }


  getData()
  {
    this.http.get("https://jsonplaceholder.typicode.com/posts/2").subscribe((data) =>  {
      this.lists.push(data);
      console.log(data);
  });

  console.log(this.lists);

  }
}


// interface SquareConfig {
//   color?: string;
//   width?: number;
// }

// function createSquare(config: SquareConfig): {color: string; area: number} {
//   let newSquare = {color: "white", area: 100};
//   if (config.color) {
//       newSquare.color = config.color;
//   }
//   if (config.width) {
//       newSquare.area = config.width * config.width;
//   }
//   return newSquare;
// }

// let mySquare = createSquare({color: "black"});
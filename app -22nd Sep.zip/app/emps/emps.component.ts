import { Component, OnInit } from '@angular/core';
import {SalaryCal} from '../oops/salarycalc'

import {Proudct} from '../model/product'

enum days {  //enum is read only 
  Monday=1,
  Tuesday,
  Wedesday,
  Thursday,
  Friday,
  Saturday,
  Sunday
}

@Component({
  selector: 'app-emps',
  templateUrl: './emps.component.html',
  styleUrls: ['./emps.component.css']
})

export class EmpsComponent implements OnInit {
  
  products


  msg='TEST meSSage'

  df=[1,2,3,5]
  names=["raman","jatin","aman","divya"]

  emps=[{id:111,name:'raman'},{id:222,name:'jatin'}]
  id 
  
  name 
  constructor(private objsal:SalaryCal) { 
  
    this.products =[];

    var ob = new Proudct(100,"Dove","50")
    this.products.push(ob)

    console.log(this.products);


    
    console.log(days.Wedesday);


  
  }

  abc(event)
  {
    console.log(event.target.value)
  }

  getSalary()
  {

    console.log(this.objsal.yearlySal(22222))

    
  }
  takeName(event)
  {
    this.name =event.target.value
  }
  takeId(event)
  {
    this.id =event.target.value
  }
  addEmployee()
  {
    //save data 
    this.emps.push({id:this.id,name:this.name})
    //read data


  }
  ngOnInit() {
  }

}

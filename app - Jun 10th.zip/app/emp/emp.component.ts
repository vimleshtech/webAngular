import { Component, OnInit } from '@angular/core';

import  {HttpClientModule, HttpClient} from '@angular/common/http'



@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

  eid 
  ename 
  employee=[]
  mcount
  umcount 
  data
  constructor(private http:HttpClient) {
    this.mcount = 0
    this.umcount = 0

    this.eid  = 0
    this.ename  = ''
    this.employee =[]
    this.data=[]

   }

  ngOnInit() {

  }
  getDataFromWebService()
  {
    this.http.get('http://jsonplaceholder.typicode.com/users').subscribe(
      res =>{  this.data = res;

      }
    );
  }


  empId(event)
  {

    this.eid  = event.target.value 

  }

  empName(event)
  {
    this.ename  = event.target.value 
  }


  addEmp(event)
  {

    this.employee.push({'eid':this.eid,'ename':this.ename,flag:false})

    console.log(this.employee)
    this.getCount()

  }

  empMark(i)
  {
    //this.employee.splice(i,1)

    
        this.employee[i].flag = !this.employee[i].flag
    
        console.log(i)
        this.getCount()

  }
  empEdit(i)
  {
      this.eid = this.employee[i].eid
      this.ename = this.employee[i].ename
  }
  updateEmp()
  {

    console.log('clicked');


    for(let i=0; i<this.employee.length;i++)
    {

      if(this.employee[i].eid == this.eid)
      {
        this.employee[i].ename = this.ename
      }
    }
    
    
  }

  getCount()
  {
    this.umcount = 0
    this.mcount = 0

    for(let i=0; i<this.employee.length;i++)
    {

      if(this.employee[i].flag == true)
      {
        this.mcount++
      }
    }

    this.umcount = this.employee.length - this.mcount

    
  }
}


import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  id: string;
  private sub: any;    

constructor(private router: Router, private route: ActivatedRoute) {
}
  ngOnInit() {
    
        this.sub = this.route.params.subscribe(params => {
            this.id = params['id'];
    });

    console.log(this.id);

}

}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http'; 

const httpOptions = { 
  headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };

@Injectable()
export class WebapiService {

  typeapiurl ="http://localhost/test/selection.php";
  bloglistapiurl ="http://localhost/test/blogslist.php";
  userapiurl ="http://localhost/test/user.php";
  constructor(private http: HttpClient) { }
  
  gettypes(){
    return this.http.get(this.typeapiurl , httpOptions);
  }

  getblogs(){
    return this.http.get(this.bloglistapiurl , httpOptions);
  }
  

}
